<!-- start footer -->

    </div>
  </div>
</div>
<!-- Go top -->
<a href="#" class="scrollup"><i class="fa fa-chevron-up"></i></a>
<!-- Go top -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?= base_url() ?>resources/js/vendor/jquery.min.js"></script>
<!-- bootstrap js -->
<script src="<?= base_url() ?>resources/js/vendor/bootstrap.min.js"></script>
<!--  chartJs js  -->
<script src="<?= base_url() ?>resources/js/vendor/chartJs/Chart.bundle.js"></script>
<!--timeline_horizontal-->
<script src="<?= base_url() ?>resources/js/vendor/jquery.mobile.custom.min.js"></script>
<script src="<?= base_url() ?>resources/js/vendor/hTimeline.js"></script>
<!-- amcharts -->
<script src="<?= base_url() ?>resources/js/vendor/amcharts/amcharts.js"></script>
<script src="<?= base_url() ?>resources/js/vendor/amcharts/serial.js"></script>
<script src="<?= base_url() ?>resources/js/vendor/amcharts/pie.js"></script>
<script src="<?= base_url() ?>resources/js/vendor/amcharts/gantt.js"></script>
<script src="<?= base_url() ?>resources/js/vendor/amcharts/funnel.js"></script>
<script src="<?= base_url() ?>resources/js/vendor/amcharts/radar.js"></script>
<script src="<?= base_url() ?>resources/js/vendor/amcharts/amstock.js"></script>
<script src="<?= base_url() ?>resources/js/vendor/amcharts/ammap.js"></script>
<script src="<?= base_url() ?>resources/js/vendor/amcharts/worldLow.js"></script>
<script src="<?= base_url() ?>resources/js/vendor/amcharts/light.js"></script>
<!-- Peity -->
<script src="<?= base_url() ?>resources/js/vendor/peityJs/jquery.peity.min.js"></script>
<!-- fullcalendar -->
<script src='<?= base_url() ?>resources/js/vendor/lib/moment.min.js'></script>
<script src='<?= base_url() ?>resources/js/vendor/lib/jquery-ui.custom.min.js'></script>
<script src='<?= base_url() ?>resources/js/vendor/fullcalendar.min.js'></script>
<!-- icheck -->
<script src="<?= base_url() ?>resources/js/vendor/icheck.js"></script>
<!-- dataTables-->
<script type="text/javascript" src="<?= base_url() ?>resources/js/vendor/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?= base_url() ?>resources/js/vendor/dataTables.bootstrap.min.js"></script>
<!-- js for print and download -->
<script type="text/javascript" src="<?= base_url() ?>resources/js/vendor/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>resources/js/vendor/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>resources/js/vendor/jszip.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>resources/js/vendor/pdfmake.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>resources/js/vendor/vfs_fonts.js"></script>
<script type="text/javascript" src="<?= base_url() ?>resources/js/vendor/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>resources/js/vendor/buttons.print.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>resources/js/vendor/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>resources/js/vendor/dataTables.fixedHeader.min.js"></script>
<!-- slimscroll js -->
<script type="text/javascript" src="<?= base_url() ?>resources/js/vendor/jquery.slimscroll.js"></script>
<!-- dashboard1 js -->
<script src="<?= base_url() ?>resources/js/dashboard1.js"></script>
<!-- pace js -->
<script src="<?= base_url() ?>resources/js/vendor/pace/pace.min.js"></script>
<!-- main js -->
<script src="<?= base_url() ?>resources/js/main.js"></script>
<!-- adminbag demo js-->
<script src="<?= base_url() ?>resources/js/adminbagdemo.js"></script>
</html>
